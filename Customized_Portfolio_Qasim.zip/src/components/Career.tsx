import "./styles/Career.css";

const Career = () => {
  return (
    <div className="career-section section-container">
      <div className="career-container">
        <h2>
          My career <span>&</span>
          <br /> experience
        </h2>
        <div className="career-info">
          <div className="career-timeline">
            <div className="career-dot"></div>
          </div>
          <div className="career-info-box">
            <div className="career-info-in">
              <div className="career-role">
                <h4>SEO & Digital Growth Specialist</h4>
                <h5>Self-Employed / Client-Based</h5>
              </div>
              <h3>2023 - NOW</h3>
            </div>
            <p>
              Led off-page SEO strategies with specialized focus on securing high-authority editorial backlinks. Built scalable AI-powered content pipelines, increasing production volume 3x while maintaining strict editorial quality and SEO integrity.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Career;
