import "./styles/About.css";

const About = () => {
  return (
    <div className="about-section" id="about">
      <div className="about-me">
        <h3 className="title">About Me</h3>
        <p className="para">
          Results-driven SEO & Digital Growth Specialist with 3+ years of hands-on experience in off-page SEO, editorial link building,
          and AI-powered content scaling. I have a proven track record of securing Tier-1 backlinks from high-authority publications, conducting
          deep search intent audits, and building sustainable Authority Pipelines that deliver measurable conversions and ROI for
          clients.
        </p>
      </div>
    </div>
  );
};

export default About;
